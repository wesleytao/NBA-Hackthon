library(dplyr)

##Load in raw files

playbyplay <- read.csv("C:\\Users\\Des\\Documents\\RClass\\NBA Hackathon\\Basketball Track\\play_by_play.csv")
lineup <- read.csv("C:\\Users\\Des\\Documents\\RClass\\NBA Hackathon\\Basketball Track\\game_lineup.csv")
eventcode <- read.csv("C:\\Users\\Des\\Documents\\RClass\\NBA Hackathon\\Basketball Track\\event_code.csv")

#Figure out which team is which in the lineup data

gameteams <- playbyplay %>% group_by(Game_id,Team_id) %>% 
    summarize(homeaway=mean(Team_id_type))

gameteams <- gameteams %>% mutate(uniqueID=paste("GAME",Game_id,"TEAM",Team_id))

lineup <- lineup %>% mutate(uniqueID=paste("GAME",Game_id,"TEAM",Team_id))

mergelineup <- merge(x=lineup,y=gameteams,by.x="uniqueID",by.y="uniqueID",all.x=TRUE,all.y=FALSE) 

lineupsort <- mergelineup[order(mergelineup$Game_id.x,mergelineup$Period,mergelineup$homeaway),]

#Order the players from 1-10 then put them into separate data frames to eventually insert into play by play data

lineupsort$playernum <- 1

for (i in 1:nrow(lineupsort)) {
    ifelse(lineupsort[i-1,"playernum"] == 10, lineupsort[i,"playernum"] <- 1,
       lineupsort[i,"playernum"] <- lineupsort[i-1,"playernum"] +1)
    
}

lineupsort <- lineupsort %>% mutate(periodID=paste("GAME",Game_id.x,"PERIOD",Period))

p1 <- lineupsort %>% filter(playernum==1)
p2 <- lineupsort %>% filter(playernum==2)
p3 <- lineupsort %>% filter(playernum==3)
p4 <- lineupsort %>% filter(playernum==4)
p5 <- lineupsort %>% filter(playernum==5)
p6 <- lineupsort %>% filter(playernum==6)
p7 <- lineupsort %>% filter(playernum==7)
p8 <- lineupsort %>% filter(playernum==8)
p9 <- lineupsort %>% filter(playernum==9)
p10 <- lineupsort %>% filter(playernum==10)

#Create columns for each player in play by play data

playbyplay$p1 <- 0
playbyplay$p2 <- 0
playbyplay$p3 <- 0
playbyplay$p4 <- 0
playbyplay$p5 <- 0
playbyplay$p6 <- 0
playbyplay$p7 <- 0
playbyplay$p8 <- 0
playbyplay$p9 <- 0
playbyplay$p10 <- 0

#Create unique ID to map to lineup data
playbyplay <- playbyplay %>% mutate(periodID=paste("GAME",Game_id,"PERIOD",Period))

#Create a column to identify the original order everything came in 
playbyplay$rownumber <- 0

for (i in 1:nrow(playbyplay)) {
    playbyplay[i,"rownumber"] <- i}

#Insert starts and track substitutions (repeat for 5 spots for each team)
for (i in 1:nrow(playbyplay)) {
    ifelse(playbyplay[i,"Event_Msg_Type"]==12,
           playbyplay[i,"p1"] <- as.character(filter(p1,periodID==playbyplay[i,"periodID"])$Person_id),
           ifelse(playbyplay[i,"Event_Msg_Type"]!=8,
                  playbyplay[i,"p1"] <- playbyplay[i-1,"p1"],
                  ifelse(playbyplay[i,"Person1"]==playbyplay[i-1,"p1"],
                         playbyplay[i,"p1"] <- as.character(playbyplay[i,"Person2"]),
                         playbyplay[i,"p1"] <- playbyplay[i-1,"p1"])
           )
    )
}

for (i in 1:nrow(playbyplay)) {
    ifelse(playbyplay[i,"Event_Msg_Type"]==12,
           playbyplay[i,"p2"] <- as.character(filter(p2,periodID==playbyplay[i,"periodID"])$Person_id),
           ifelse(playbyplay[i,"Event_Msg_Type"]!=8,
                  playbyplay[i,"p2"] <- playbyplay[i-1,"p2"],
                  ifelse(playbyplay[i,"Person1"]==playbyplay[i-1,"p2"],
                         playbyplay[i,"p2"] <- as.character(playbyplay[i,"Person2"]),
                         playbyplay[i,"p2"] <- playbyplay[i-1,"p2"])
           )
    )
}

for (i in 1:nrow(playbyplay)) {
    ifelse(playbyplay[i,"Event_Msg_Type"]==12,
           playbyplay[i,"p3"] <- as.character(filter(p3,periodID==playbyplay[i,"periodID"])$Person_id),
           ifelse(playbyplay[i,"Event_Msg_Type"]!=8,
                  playbyplay[i,"p3"] <- playbyplay[i-1,"p3"],
                  ifelse(playbyplay[i,"Person1"]==playbyplay[i-1,"p3"],
                         playbyplay[i,"p3"] <- as.character(playbyplay[i,"Person2"]),
                         playbyplay[i,"p3"] <- playbyplay[i-1,"p3"])
           )
    )
}

for (i in 1:nrow(playbyplay)) {
    ifelse(playbyplay[i,"Event_Msg_Type"]==12,
           playbyplay[i,"p4"] <- as.character(filter(p4,periodID==playbyplay[i,"periodID"])$Person_id),
           ifelse(playbyplay[i,"Event_Msg_Type"]!=8,
                  playbyplay[i,"p4"] <- playbyplay[i-1,"p4"],
                  ifelse(playbyplay[i,"Person1"]==playbyplay[i-1,"p4"],
                         playbyplay[i,"p4"] <- as.character(playbyplay[i,"Person2"]),
                         playbyplay[i,"p4"] <- playbyplay[i-1,"p4"])
           )
    )
}

for (i in 1:nrow(playbyplay)) {
    ifelse(playbyplay[i,"Event_Msg_Type"]==12,
           playbyplay[i,"p5"] <- as.character(filter(p5,periodID==playbyplay[i,"periodID"])$Person_id),
           ifelse(playbyplay[i,"Event_Msg_Type"]!=8,
                  playbyplay[i,"p5"] <- playbyplay[i-1,"p5"],
                  ifelse(playbyplay[i,"Person1"]==playbyplay[i-1,"p5"],
                         playbyplay[i,"p5"] <- as.character(playbyplay[i,"Person2"]),
                         playbyplay[i,"p5"] <- playbyplay[i-1,"p5"])
           )
    )
}

for (i in 1:nrow(playbyplay)) {
    ifelse(playbyplay[i,"Event_Msg_Type"]==12,
           playbyplay[i,"p6"] <- as.character(filter(p6,periodID==playbyplay[i,"periodID"])$Person_id),
           ifelse(playbyplay[i,"Event_Msg_Type"]!=8,
                  playbyplay[i,"p6"] <- playbyplay[i-1,"p6"],
                  ifelse(playbyplay[i,"Person1"]==playbyplay[i-1,"p6"],
                         playbyplay[i,"p6"] <- as.character(playbyplay[i,"Person2"]),
                         playbyplay[i,"p6"] <- playbyplay[i-1,"p6"])
           )
    )
}

for (i in 1:nrow(playbyplay)) {
    ifelse(playbyplay[i,"Event_Msg_Type"]==12,
           playbyplay[i,"p7"] <- as.character(filter(p7,periodID==playbyplay[i,"periodID"])$Person_id),
           ifelse(playbyplay[i,"Event_Msg_Type"]!=8,
                  playbyplay[i,"p7"] <- playbyplay[i-1,"p7"],
                  ifelse(playbyplay[i,"Person1"]==playbyplay[i-1,"p7"],
                         playbyplay[i,"p7"] <- as.character(playbyplay[i,"Person2"]),
                         playbyplay[i,"p7"] <- playbyplay[i-1,"p7"])
           )
    )
}

for (i in 1:nrow(playbyplay)) {
    ifelse(playbyplay[i,"Event_Msg_Type"]==12,
           playbyplay[i,"p8"] <- as.character(filter(p8,periodID==playbyplay[i,"periodID"])$Person_id),
           ifelse(playbyplay[i,"Event_Msg_Type"]!=8,
                  playbyplay[i,"p8"] <- playbyplay[i-1,"p8"],
                  ifelse(playbyplay[i,"Person1"]==playbyplay[i-1,"p8"],
                         playbyplay[i,"p8"] <- as.character(playbyplay[i,"Person2"]),
                         playbyplay[i,"p8"] <- playbyplay[i-1,"p8"])
           )
    )
}

for (i in 1:nrow(playbyplay)) {
    ifelse(playbyplay[i,"Event_Msg_Type"]==12,
           playbyplay[i,"p9"] <- as.character(filter(p9,periodID==playbyplay[i,"periodID"])$Person_id),
           ifelse(playbyplay[i,"Event_Msg_Type"]!=8,
                  playbyplay[i,"p9"] <- playbyplay[i-1,"p9"],
                  ifelse(playbyplay[i,"Person1"]==playbyplay[i-1,"p9"],
                         playbyplay[i,"p9"] <- as.character(playbyplay[i,"Person2"]),
                         playbyplay[i,"p9"] <- playbyplay[i-1,"p9"])
           )
    )
}

for (i in 1:nrow(playbyplay)) {
    ifelse(playbyplay[i,"Event_Msg_Type"]==12,
           playbyplay[i,"p10"] <- as.character(filter(p10,periodID==playbyplay[i,"periodID"])$Person_id),
           ifelse(playbyplay[i,"Event_Msg_Type"]!=8,
                  playbyplay[i,"p10"] <- playbyplay[i-1,"p10"],
                  ifelse(playbyplay[i,"Person1"]==playbyplay[i-1,"p10"],
                         playbyplay[i,"p10"] <- as.character(playbyplay[i,"Person2"]),
                         playbyplay[i,"p10"] <- playbyplay[i-1,"p10"])
           )
    )
}

##Assign play by play points to correct plays (move free throw points to the line where the foul occurs)
#Create columns to track fouls

playbyplay$team2fouls <- 0
playbyplay$team3fouls <- 0

playbyplay[1,"Event_Msg_Type"]

#Track team2 fouls
for (i in 1:nrow(playbyplay)) {
    ifelse(playbyplay[i,"Event_Msg_Type"] == 12, playbyplay[i,"team2fouls"] <- 0,
           ifelse(playbyplay[i,"Event_Msg_Type"] == 6 && 
                      playbyplay[i,"Team_id_type"] == 2, playbyplay[i,"team2fouls"] <-  playbyplay[i-1,"team2fouls"] + 1,
                  playbyplay[i,"team2fouls"] <- playbyplay[i-1,"team2fouls"]))
}

#Track team3 fouls
for (i in 1:nrow(playbyplay)) {
    ifelse(playbyplay[i,"Event_Msg_Type"] == 12, playbyplay[i,"team3fouls"] <- 0,
           ifelse(playbyplay[i,"Event_Msg_Type"] == 6 && 
                      playbyplay[i,"Team_id_type"] == 3, playbyplay[i,"team3fouls"] <-  playbyplay[i-1,"team3fouls"] + 1,
                  playbyplay[i,"team3fouls"] <- playbyplay[i-1,"team3fouls"]))
}


## assign free throws to point of foul

#First identify free throw points

playbyplay <- playbyplay %>% mutate(
    free_throw_points2=ifelse(Option1==1,
                              ifelse(Team_id_type==2,
                                     ifelse(Event_Msg_Type==3,1,0),
                                     0),
                              0),
    free_throw_points3=ifelse(Option1==1,
                              ifelse(Team_id_type==3,
                                     ifelse(Event_Msg_Type==3,1,0),
                                     0),
                              0)
)
                                    
                                                                       

#Then assign points to specific fouls

freethrows2 <- playbyplay %>% group_by(Game_id,Period,team2fouls) %>% 
    summarize(team2ftpts=sum(free_throw_points2))

freethrows3 <- playbyplay %>% group_by(Game_id,Period,team3fouls) %>% 
    summarize(team3ftpts=sum(free_throw_points3))

#Create unique id in one column to match free throw points with proper row in play by play
playbyplay <- playbyplay %>% mutate(uniqueid2=paste("GAME",Game_id,"PERIOD",Period,"TEAM2FOULS",team2fouls),
                                    uniqueid3=paste("GAME",Game_id,"PERIOD",Period,"TEAM3FOULS",team3fouls))

freethrows2 <- freethrows2 %>% mutate(uniqueid2=paste("GAME",Game_id,"PERIOD",Period,"TEAM2FOULS",team2fouls))
freethrows3 <- freethrows3 %>% mutate(uniqueid3=paste("GAME",Game_id,"PERIOD",Period,"TEAM3FOULS",team3fouls))


#Merge free throw data with play by play data
mergepbp <- merge(x=playbyplay,y=freethrows2,by.x="uniqueid2",by.y="uniqueid2")
mergepbp <- merge(x=mergepbp,y=freethrows3,by.x="uniqueid3",by.y="uniqueid3")

#Ensure everything is ordered properly post-merge
mergepbp <- mergepbp[order(mergepbp$Game_id.x,mergepbp$Period,-mergepbp$PC_Time,mergepbp$rownumber),]

#Create adjusted score column that assigns points at correct point in time for free throw situations
for (i in 1:nrow(mergepbp))  {
    ifelse(mergepbp[i,"Team_id_type"]==2,
                    ifelse(mergepbp[i,"team2fouls.x"] == mergepbp[i-1,"team2fouls.x"],
                           ifelse(mergepbp[i,"Event_Msg_Type"]==1,
                                  mergepbp[i,"adjustedscoreteam2"] <- mergepbp[i,"Option1"],
                                  mergepbp[i,"adjustedscoreteam2"] <- 0),
                           mergepbp[i,"adjustedscoreteam2"] <- mergepbp[i,"team2ftpts"]),
           mergepbp[i,"adjustedscoreteam2"] <- 0)
}


for (i in 1:nrow(mergepbp))  {
    ifelse(mergepbp[i,"Team_id_type"]==3,
           ifelse(mergepbp[i,"team3fouls.x"] == mergepbp[i-1,"team3fouls.x"],
                  ifelse(mergepbp[i,"Event_Msg_Type"]==1,
                         mergepbp[i,"adjustedscoreteam3"] <- mergepbp[i,"Option1"],
                         mergepbp[i,"adjustedscoreteam3"] <- 0),
                  mergepbp[i,"adjustedscoreteam3"] <- mergepbp[i,"team3ftpts"]),
           mergepbp[i,"adjustedscoreteam3"] <- 0)
}


#Create columns for all ten players on floor to track plus/minus on each play
mergepbp <- mergepbp %>% mutate(T2P1=adjustedscoreteam2-adjustedscoreteam3,
                                T2P2=adjustedscoreteam2-adjustedscoreteam3,
                                T2P3=adjustedscoreteam2-adjustedscoreteam3,
                                T2P4=adjustedscoreteam2-adjustedscoreteam3,
                                T2P5=adjustedscoreteam2-adjustedscoreteam3,
                                T3P1=adjustedscoreteam3-adjustedscoreteam2,
                                T3P2=adjustedscoreteam3-adjustedscoreteam2,
                                T3P3=adjustedscoreteam3-adjustedscoreteam2,
                                T3P4=adjustedscoreteam3-adjustedscoreteam2,
                                T3P5=adjustedscoreteam3-adjustedscoreteam2)

#Clean up data frame to show only relevant columns 
mergepbp2 <- mergepbp %>% select(Game_id.x,Period.x,Event_Num,Event_Msg_Type,Person1,
                                Person2,adjustedscoreteam2,adjustedscoreteam3,rownumber,
                                p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,
                                T2P1,T2P2,T2P3,T2P4,T2P5,T3P1,T3P2,T3P3,T3P4,T3P5)
#Create separate data frames for each position as players may move in between slots and this needs to be accounted for

T2P1frame <- mergepbp2 %>% select(Game_id.x,p1,T2P1) %>% mutate(team=2)
colnames(T2P1frame) <- c("game","player","pm","team")

T2P2frame <- mergepbp2 %>% select(Game_id.x,p2,T2P2) %>% mutate(team=2)
colnames(T2P2frame) <- c("game","player","pm","team")

T2P3frame <- mergepbp2 %>% select(Game_id.x,p3,T2P3) %>% mutate(team=2)
colnames(T2P3frame) <- c("game","player","pm","team")

T2P4frame <- mergepbp2 %>% select(Game_id.x,p4,T2P4) %>% mutate(team=2)
colnames(T2P4frame) <- c("game","player","pm","team")

T2P5frame <- mergepbp2 %>% select(Game_id.x,p5,T2P5) %>% mutate(team=2)
colnames(T2P5frame) <- c("game","player","pm","team")

T3P1frame <- mergepbp2 %>% select(Game_id.x,p6,T3P1) %>% mutate(team=3)
colnames(T3P1frame) <- c("game","player","pm","team")

T3P2frame <- mergepbp2 %>% select(Game_id.x,p7,T3P2) %>% mutate(team=3)
colnames(T3P2frame) <- c("game","player","pm","team")

T3P3frame <- mergepbp2 %>% select(Game_id.x,p8,T3P3) %>% mutate(team=3)
colnames(T3P3frame) <- c("game","player","pm","team")

T3P4frame <- mergepbp2 %>% select(Game_id.x,p9,T3P4) %>% mutate(team=3)
colnames(T3P4frame) <- c("game","player","pm","team")

T3P5frame <- mergepbp2 %>% select(Game_id.x,p10,T3P5) %>% mutate(team=3)
colnames(T3P5frame) <- c("game","player","pm","team")

#Bind all positions together (10x the rows)
fullframe <- rbind(T2P1frame,T2P2frame,T2P3frame,T2P4frame,T2P5frame,
                   T3P1frame,T3P2frame,T3P3frame,T3P4frame,T3P5frame)

#Summarize to roll up to player level
plusminus <- fullframe %>% group_by(game,team,player) %>% 
    summarize(plusminus=sum(pm))

#Order from highest to lowest +/-
plusminus <- plusminus[order(plusminus$game,plusminus$team,-plusminus$plusminus),]

write.csv(plusminus,"C:\\Users\\Des\\Documents\\RClass\\NBA Hackathon\\Basketball Track\\Take_That_For_Data_Q1_BBALL.csv")

#Calc final scores for each game to identify games on basketball-reference for comparison
finalscores <- mergepbp %>% group_by(Game_id) %>% 
    summarize(team2score=sum(adjustedscoreteam2),
              team3score=sum(adjustedscoreteam3))